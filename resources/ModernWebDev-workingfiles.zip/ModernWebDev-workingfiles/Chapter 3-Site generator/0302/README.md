# An Introduction to Modern Front-End Development

This contains the MarsBQ example site we're developing as part of this course. The example file is at the **beginning** state of the chapter. To see the completed version of the chapter, take a look at the next chapter's file. If you're following along with the full course, you may only need to access certain files from this directory and include them in your project.

Are you stuck? Have questions? Contact me!

@adamdscott
adam@learnfrontend.io
