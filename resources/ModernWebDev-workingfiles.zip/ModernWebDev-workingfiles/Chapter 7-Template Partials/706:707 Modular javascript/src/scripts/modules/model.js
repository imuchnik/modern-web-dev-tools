var model = module.exports = {
  init: function() {
    console.log('Model initialized');
  },

  currentDate: new Date(),
  eventDate: new Date(2056, 10, 05)
};
