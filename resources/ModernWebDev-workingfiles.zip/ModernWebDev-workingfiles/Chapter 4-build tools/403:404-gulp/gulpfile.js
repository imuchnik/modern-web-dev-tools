var gulp = require('gulp');

gulp.task('default', function(){
  console.log('Your first task has run!');
});
